@org.junit.jupiter.api.Test
public void ${NAME}() {
// hello
  assertThat(true).isTrue()
}